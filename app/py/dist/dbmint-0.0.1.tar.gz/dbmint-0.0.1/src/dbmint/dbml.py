from typing import List
import dbml_sqlite
from dbml_sqlite import PyDBML
from pydbml.classes import Table, Column, Note

from .common import MOUNT_PATH

import unittest
class DbmlUnitTests(unittest.TestCase):
    def test_something(self) -> None:
        self.assertTrue(False, "rigorous test :)")

    def test_example_parsing_dbml(self) -> None:
        dbml_path = f'{MOUNT_PATH}ex000.dbml'

        self.assertTrue(dbml_sqlite.validDBMLFile(dbml_path), f'Invalid dbml file: {dbml_path}');

        dbml_data = dbml_sqlite.PyDBML.parse_file(dbml_path)

        # prints [Table('Users', [Column('id', 'integer', pk=True), Column('username', 'varchar'), Column('role', 'varchar'), Column('created_at', 'varchar')]), Table('Posts', [Column('id', 'integer', pk=True), Column('title', 'varchar'), Column('body', 'varchar', note=Note('Content of the post')), Column('status', 'varchar'), Column('created_at', 'varchar')]), Table('User_Owns_Posts', [Column('id', 'integer', pk=True), Column('from_user_id', 'integer'), Column('to_post_id', 'integer')])]
        # print(dbml_data.tables)

        expected_tables = [
            Table('Users', columns=[
                Column('id', 'integer', pk=True),
                Column('username', 'varchar'),
                Column('role', 'varchar'),
                Column('created_at', 'varchar'),
            ]),

            Table('Posts', columns=[
                Column('id', 'integer', pk=True),
                Column('title', 'varchar'), 
                Column('body', 'varchar', note=Note('Content of the post')), 
                Column('status', 'varchar'), 
                Column('created_at', 'varchar'), 
            ]),

            Table('User_Owns_Posts', columns=[
                Column('id', 'integer', pk=True), 
                Column('from_user_id', 'integer'), 
                Column('to_post_id', 'integer'),
            ])
        ]

        self.assertEqual(dbml_data.tables[0], expected_tables[0])

        # print(dbml_data.table_dict)

        # print(dbml_data.project) # prints None

        self.assertTrue(True, "Toggle to show example")